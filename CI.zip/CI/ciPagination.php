<?php
$start_limit = ($this->uri->segment(3)>0)?$this->uri->segment(3):0;
$end_limit = 2;
$limit = "LIMIT $start_limit,$end_limit";
$total = count($this->Common_model->getReceiveOrder($where));      
$data['links'] = $this->paginationRecord($total,'receive_orders/'.$pagename,'3',$start_limit,$end_limit);
$data['sno'] = $start_limit+1; // serial number list foreach $sno++;
========================

public function paginationRecord($total,$pagename,$uri_segment='3',$start_limit=0,$end_limit=50)
{        
    $config = array();
    $config["base_url"] = base_url().$pagename;
    $config["total_rows"] = $total;
    $config["per_page"] = $end_limit;
    $config["uri_segment"] = $uri_segment;        

    $config['cur_tag_open'] = '&nbsp;<a class="current">';
    $config['cur_tag_close'] = '</a>';
    $config['next_link'] = 'Next';
    $config['prev_link'] = 'Previous';

    $this->pagination->initialize($config);

    $page = $start_limit;
    return $this->pagination->create_links();

}

=======Html page=========
</table>
<div id="pagination">
    <ul class="tsc_pagination">
        <li>
        <?php
            if(!empty($links)){
                echo $links;
            }
        ?>
        </li>
    </ul>
</div>

===========Routes==========

$route['receive_orders/(:any)'] = 'front/receive_orders/$1';
$route['receive_orders/(:any)/(:any)'] = 'front/receive_orders/$1/$2';