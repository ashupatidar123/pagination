<?php
public function search_order($where)
{
    $service_id = $this->input->post('service');
    $total = $this->input->post('total');
    $price = $this->input->post('price');
    $address = $this->input->post('address');

    if(!empty($service_id)){
      $where .= " AND b.service_id=$service_id";
      $this->session->set_userdata('service_id',$service_id);
    }

    if(!empty($total)){
      $where .= " AND b.total_price=$total";
      $this->session->set_userdata('total',$total);
    }
      
    if(!empty($price)){
      $where .= " AND b.price=$price";
      $this->session->set_userdata('price',$price);
    }
      
    if(!empty($address)){
      $where .= " AND b.address LIKE '$address%'";
      $this->session->set_userdata('address',$address);      
    }
    return $where;
}

====================================================
public function receive_orders($pagename='',$num='')
{
  
	  $session_data = $this->session->userdata('logged_in'); 
	  $login_user_id = $session_data['id'];
	  
	  $where = "WHERE ";
	  if($pagename=='pending'){
	    $where .= "b.ser_provider_id=$login_user_id AND b.service_status=0 AND b.status=0";
	  }
	  else if($pagename=='ongoing'){
	    $where .= "b.ser_provider_id=$login_user_id AND b.service_status=1 AND b.status=1";
	  }
	  
	  else if($pagename=='expired'){
	    $where .= "b.ser_provider_id=$login_user_id AND b.status=2";
	  }
	  else if($pagename=='cancel'){
	    $where .= "b.ser_provider_id=$login_user_id AND b.status=3";
	  }
	  else if($pagename=='complete'){
	    $where .= "b.ser_provider_id=$login_user_id AND b.status=4";
	  }
	  else {
	    redirect(base_url());
	  }

	  if(isset($_POST['search_order']))
	  {        
	    $where = $this->search_order($where);
	  }
	  else if(isset($_POST['search_order_s_unset'])) //pager refresh then session unset
	  {
	    $array_items = array('service_id','address','price','total');
	    $this->session->unset_userdata($array_items);
	  }

	  if(!empty($this->session->userdata('service_id'))){
	    $service_id = $this->session->userdata('service_id');
	    $where .= " AND b.service_id=$service_id";
	  }
	  if(!empty($this->session->userdata('address'))){
	    $address = $this->session->userdata('address');
	    $where .= " AND b.address LIKE '$address%'";
	  }
	  if(!empty($this->session->userdata('price'))){
	    $price = $this->session->userdata('price');
	    $where .= " AND b.price=$price";
	  }
	  if(!empty($this->session->userdata('total'))){
	    $total = $this->session->userdata('total');
	    $where .= " AND b.total_price=$total";
	  }

	  $start_limit = ($this->uri->segment(3)>0)?$this->uri->segment(3):0;
	  $end_limit = 2;
	  $limit = "LIMIT $start_limit,$end_limit";
	  $total = count($this->Common_model->getReceiveOrder($where));      
	  $data['links'] = $this->paginationRecord($total,'receive_orders/'.$pagename,'3',$start_limit,$end_limit);
	  $data['sno'] = $start_limit+1;

	  $data['order'] = $this->Common_model->getReceiveOrder($where,$limit);
	  //$this->print($data);      
	  $data['pagename'] = $pagename;
	  $data['body']    = 'receive_orders';  
	  $this->controller->load_view($data);
}

==================Search Form=====================

$pagename = like this pending,cancel,ongoing 
<div>
    <form method="post" class="form-horizontal" action="<?=base_url('receive_orders/').$pagename;?>">
      <div class="form-group">
        <div class="col-sm-3">
          <select class="form-control" name="service">
              <option value="" hidden="">---Select service---</option>
              <?php
                foreach($order as $srv)
                {   ?>
                        <option value="<?=$srv['service_id'];?>" <?=($this->session->userdata('service_id')==$srv['service_id'])?'selected':'';?>><?=$srv['service_type'];?></option>
                    <?php
                }
              ?>                              
          </select>                          
        </div>
        <div class="col-sm-3">
          <input type="text" class="form-control" name="total" placeholder="Enter total" value="<?=!empty($this->session->userdata('total'))?$this->session->userdata('total'):'';?>">
        </div>
        <div class="col-sm-3">
          <input type="text" class="form-control" name="price" placeholder="Enter price" value="<?=!empty($this->session->userdata('price'))?$this->session->userdata('price'):'';?>">
        </div>
        <div class="col-sm-3">
          <input type="text" class="form-control" name="address" placeholder="Enter address" value="<?=!empty($this->session->userdata('address'))?$this->session->userdata('address'):'';?>">
        </div>
      </div>
      
      <div class="form-group">
        <div class="col-sm-8">
          <button type="submit" name="search_order" class="btn btn-primary btn btn-md">Search</button>
          <button type="submit" name="search_order_s_unset" class="btn btn-danger btn btn-md">Refresh</button>
        </div>

      </div>
    </form>
</div>