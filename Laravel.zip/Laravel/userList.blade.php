  @extends('admin.header')
  @section('title','Register Form')  
  
  @section('content')
 
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>User List</h1>
            <a href="{{url('webpanel/register')}}" class="btn btn-primary"><i class="fa fa-list"></i> Add User</a>
            <h4 class="text-success">Total Users: {{$total}}</h4>

            @if($alert = Session::get('alert'))
              <div class="alert alert-{{$alert}} alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong>{{ Session::get('message') }}</strong>
              </div>
            @endif
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard">Home</a></li>
              <li class="breadcrumb-item active">List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <!-- <div class="card-header">
              <h3 class="card-title">Register user record</h3>
            </div> -->
            <!-- /.card-header -->
            <div class="card-body table-responsive tableFixHead">
              <table id="example12" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Sno</th>
                  <th>User ID</th>
                  <th>Name</th>
                  <th>Username</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  <th>Register Date</th>
                  <th>Action</th>
                </tr>
                </thead>
                <body>
                  <?php   
                  //$var = new AdminController();
                  $sno;
                  foreach($record as $row)
                  { 
                      $user_id = $row->user_id;
                      $userId  = App\Http\Controllers\CoreController::id_string($user_id);
                      //$userId  = $var->id_string1($user_id);
                    ?>
                    <tr>
                      <td>{{$sno++}}</td>
                      <td>{{$row->user_id}}</td>
                      <td>{{$row->Name}}</td>
                      <td>{{$row->username}}</td>
                      <td>{{$row->Mobile}}</td>
                      <td>{{$row->Email}}</td>
                      <td>{{$row->created_date}}</td>
                      <td>
                        <a href="{{url('webpanel/editUser')}}/{{$userId}}/userList" class="btn btn-sm btn btn-primary"><i class="fa fa-edit"></i></a>
                        <a href="javascript:void(0);" class="btn btn-sm btn btn-danger" onclick="recordDelete('{{$userId}}','userList');"><i class="fa fa-trash"></i></a>

                      </td>
                    </tr>
                  <?php
                  } ?>  
                </body>
              </table>
            </div>  
            <p>
                <?php
                    echo $pagination;
                ?>

            </p>
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  @endsection